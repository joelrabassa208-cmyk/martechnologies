# Cómo publicar martechnologies.ar

La web ya está construida en la carpeta `mar-web`. Publicarla lleva **3 etapas**. Hacelas en este orden.

---

## Etapa 1 — Subir la web a GitHub (unos 10 minutos)

1. Entrá a **github.com** con tu cuenta **joelrabassa208-cmyk**.
2. Arriba a la derecha tocá **+** y luego **New repository**.
   - **Repository name:** `martechnologies`
   - Marcá **Public**. GitHub Pages gratis solo funciona con repositorios públicos.
   - Tocá **Create repository**.
3. En la pantalla siguiente, tocá el enlace **"uploading an existing file"**.
4. Abrí la carpeta `mar-web` en tu computadora. Seleccioná **todo lo que hay adentro** (no la carpeta en sí) y arrastralo a la página de GitHub.
   - Tienen que aparecer `index.html`, `CNAME`, `sitemap.xml`, `robots.txt`, `404.html` y las carpetas `assets`, `historia`, `servicios`, `proyectos`, `como-trabajamos`, `alianzas`, `contacto` y `privacidad`.
   - Usá Chrome o Edge, que permiten arrastrar carpetas.
5. Abajo, tocá **Commit changes**.
6. Andá a **Settings** y después a **Pages**, en el menú de la izquierda.
   - En **Source** elegí **Deploy from a branch**.
   - En **Branch** elegí **main** y la carpeta **/ (root)**, y tocá **Save**.
   - En **Custom domain** tiene que figurar `martechnologies.ar`. Si no figura, escribilo y tocá **Save**.

En 1 o 2 minutos la web ya se ve en `https://joelrabassa208-cmyk.github.io/martechnologies/`. El dominio propio empieza a funcionar recién cuando termines la etapa 3.

---

## Etapa 2 — Crear el DNS gratis en Cloudflare (unos 10 minutos)

NIC Argentina registra el dominio, pero no permite cargar los registros que necesita GitHub. Para eso se usa un servicio de DNS gratuito como Cloudflare.

1. Creá una cuenta gratis en **cloudflare.com**.
2. Tocá **Add a domain** (o **Add site**), escribí `martechnologies.ar` y elegí el plan **Free**.
3. Andá a **DNS** y luego a **Records**. Borrá los registros que Cloudflare haya importado y creá estos (en todos, **Proxy status: DNS only**, con la nube gris):

| Tipo | Nombre | Contenido |
|---|---|---|
| A | `@` | `185.199.108.153` |
| A | `@` | `185.199.109.153` |
| A | `@` | `185.199.110.153` |
| A | `@` | `185.199.111.153` |
| AAAA | `@` | `2606:50c0:8000::153` |
| AAAA | `@` | `2606:50c0:8001::153` |
| AAAA | `@` | `2606:50c0:8002::153` |
| AAAA | `@` | `2606:50c0:8003::153` |
| CNAME | `www` | `joelrabassa208-cmyk.github.io` |

4. Cloudflare te va a mostrar **dos nameservers**, del estilo `ana.ns.cloudflare.com` y `bob.ns.cloudflare.com`. Anotalos.

---

## Etapa 3 — Delegar el dominio en NIC Argentina (unos 5 minutos + espera)

1. Entrá a **nic.ar** con tu cuenta y buscá `martechnologies.ar`.
2. Tocá **Delegar** y después **Añadir una nueva delegación**.
3. Cargá los **dos nameservers de Cloudflare**, uno por uno, y guardá cada uno.
4. Tocá **Ejecutar cambios** y confirmá.
5. **Esperá.** La propagación puede tardar entre unas horas y 48 horas. Cloudflare te avisa por correo cuando el dominio queda activo.

Cuando ya funcione, volvé a GitHub, a **Settings** y luego **Pages**, y activá **Enforce HTTPS**. Si la opción aparece gris, esperá un rato: GitHub tiene que generar el certificado de seguridad.

---

## Al final — Activar el formulario de contacto

1. Entrá a `https://martechnologies.ar/contacto/` y mandá una consulta de prueba.
2. Te va a llegar un correo de **FormSubmit** a joelrabassa208@gmail.com pidiendo que confirmes. Tocá **Activate form**. Si no lo ves, revisá Spam.
3. Desde ese momento, todas las consultas te llegan a tu Gmail.

## Pendientes (no bloquean la publicación)

- **Nishimoto Selector** está oculto. Cuando tengas la autorización de la marca, se agrega.
- **Revisá la política de privacidad** en `/privacidad/`.
- **Opcional:** en Google Search Console agregá `martechnologies.ar` y cargá el sitemap `https://martechnologies.ar/sitemap.xml`, para que Google encuentre la web más rápido.
